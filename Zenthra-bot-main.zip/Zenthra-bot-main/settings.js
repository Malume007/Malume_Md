const settings = {
  packname: 'zenthra',
  author: '‎',
  botName: "Zenthra-MD",
  botOwner: '𝙼𝚊𝚕𝚟𝚒𝚗 𝙺𝚒𝚗𝚐', // Your name
  ownerNumber: '263776388689', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "0.0.1",
  menuImageUrl: "https://files.catbox.moe/rjrgn3.jpg",
};

module.exports = settings;
